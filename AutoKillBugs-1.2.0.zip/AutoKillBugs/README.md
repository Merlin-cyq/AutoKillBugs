# AutoKillBugs — 蛆/苍蝇出现即死（保留原生掉落与击杀进度）

星露谷物语 **1.6.15** + **SMAPI 4.5.2** 的代码模组（SMAPI Mod，非内容包）。

当前版本 **1.2.0**（新增游戏内设置入口：默认热键 **F9** 打开原生风格设置菜单；装了 GMCM 的话也能在标题界面 `Mod Options` 里调同样三项。**击杀逻辑与 1.1.0 完全一致**，差异清单见 §8）。

装上以后：矿井、骷髅洞穴、采石场矿井（含危险矿井）与突变虫穴里的**蛆(Grub)**、**苍蝇(Fly)**（含它们的强化变体）在进入世界后会被游戏自己的击杀流程处理掉 —— 用默认配置（`DelayOneFrame=true`）时玩家最多只会看到它们**一帧**（约 1/60 秒），把 `DelayOneFrame` 改成 `false` 则一帧都看不到；两种模式下**掉落物、经验值、探险家公会击杀进度全部照常计入**（取舍见 §3.1）。

---

## 1. 它解决的问题（为什么不用「简单删掉怪物」）

用户要的是「看到蛆/苍蝇会难受，所以别让我看到」，而不是「打不过」。但游戏里**只有一条路**能同时做到「看不到」+「掉落与进度不丢」：

| 做法 | 结果 |
| --- | --- |
| 直接 `characters.Remove(monster)` | ❌ 不掉落、不计击杀、不给经验（游戏自身的 `updateCharacters` 就是这么静默删的） |
| 只把 `Health = 0` | ❌ 同上（`ShouldMonsterBeRemoved()` 判定后被静默移除） |
| 隐藏贴图 / 改刷怪表 | ❌ 怪物仍在，或干脆不生成 → 没有掉落、没有击杀数 |
| **调用 `GameLocation.damageMonster(...)`** | ✅ 与玩家挥武器/扔炸弹命中怪物**完全同一条路径** |

`damageMonster` 在怪物血量归零时会调用 `GameLocation.onMonsterKilled(...)`，从而完整触发：

- `Game1.stats.monsterKilled(monster.Name)` → 探险家公会「杀死洞穴昆虫」计数（`Grub` / `Fly` / `Bug` 合计 80 只）
- `GameLocation.monsterDrop(...)` → 按原版 `Data/Monsters` 掉落表掉落（虫肉、古代种子、矮人卷轴等）
- 任务 `Quest.OnMonsterSlain`、特殊订单、附魔「杀戮」、戒指等全部原生钩子
- 最后才由**游戏自己**执行 `GameLocation.characters.Remove(monster)`

本模组只做这一件事；其余一切（掉落、计数、经验、任务）都是游戏原本的逻辑在跑。

## 2. 实际效果

- **看不到怪**：击杀发生在 `Game1.Update` 之后、同一帧的 `Draw` 之前，所以蛆/苍蝇在被加入 `characters` 的**那一帧内**就已被移除，从未被绘制。
  例外：把 `DelayOneFrame` 设为 `true`（当前默认）时会**刻意**推迟到下一帧才杀，虫子会在画面上**闪一帧**（约 1/60 秒）—— 这是为了换取游戏在怪物首次 `update` 时追加的加成掉落，取舍见 §3.1。
- **掉落照常**：掉在地上的还是原版掉落，例如虫肉（`684`，蛆 60% / 苍蝇 90%）、古代种子（`114`，文物）、矮人卷轴 I–IV（`96`–`99`）等。
- **击杀进度照常**：`Game1.stats.specificMonstersKilled["Grub" / "Fly"]` 每杀一只 +1，公会看板「杀死洞穴昆虫」正常推进。
- **视觉/听觉也干净**：死亡爆浆粒子（`TemporaryAnimatedSprite`）与飘出的伤害数字（`Debris`）会被立即抹掉；`slimeHit` / `slimedead` / `hitEnemy` / `monsterdead` 这些死亡音效会被 Harmony 前缀补丁压掉（详见 §5）。
- **强化变体同样处理**：1.6.15 里并不存在独立的「突变蛆 / 突变苍蝇」类或名字 —— 突变虫穴与危险矿井里的就是同一个 `Grub`/`Fly` 类、构造时传 `hard: true`（血量、伤害、掉落经验更高，`Name` 仍是 `Grub`/`Fly`），所以按类型判断即可全覆盖。

## 3. 配置项（`config.json`）

首次运行时 SMAPI 会在模组文件夹里自动生成 `config.json`：

```json
{
  "Enabled": true,
  "OnlyInMines": true,
  "DelayOneFrame": true
}
```

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| `Enabled` | `true` | 模组总开关。设为 `false` 时本模组什么都不做（等价于没装）。 |
| `OnlyInMines` | `true` | 是否只在矿井类地点生效：矿井、骷髅洞穴、采石场矿井（含危险矿井）、突变虫穴。设为 `false` 则对所有地点生效（例如其它 Mod 加的地下城）。 |
| `DelayOneFrame` | `true` | 击杀时机。<br>`true` = **延迟一帧**：怪物出现后先登记，下一个游戏 tick 才击杀。每只怪都会先跑完一次 `Monster.update()`，于是 `Monster.InitializeForLocation(...)`（`sv-Monster.cs:677-683` → `:476-520`）会生效，随怪物生成追加的**加成掉落**完整保留；代价是虫子会在画面上**闪一帧**。<br>`false` = **当帧击杀**：在怪物加入 `characters` 的同一 tick 内击杀，一帧都不会被绘制；但在 `updateCharacters` 之后才加入的怪物（典型：蛹化蛆孵化出的苍蝇，`sv-Grub.cs:234`）从未被 `update` 过，会拿不到上面那部分加成掉落。 |

改完保存，重进游戏或重新读档即可生效（不需要重启游戏进程）。想临时关掉又不想删模组，把 `Enabled` 改成 `false` 最省事。

### 3.1 两种击杀时机的取舍（`DelayOneFrame`）

| | `DelayOneFrame: true`（默认） | `DelayOneFrame: false` |
| --- | --- | --- |
| 画面 | 虫子**闪一帧**（约 1/60 秒，随后立即死亡消失） | **一帧都看不到** |
| 视觉残留 | 死亡粒子与伤害数字仍被抹掉 | 同左 |
| 音效 | 死亡音效仍被压掉；虫子这一帧自身的动作音（例：苍蝇的 `flybuzzing` 嗡鸣）**可能会起个头**，它死亡时会由游戏自己 `buzz?.Stop(...)`（`sv-Fly.cs:104`）停掉 | 完全不会有任何声音（它从未被 `update` 过） |
| 原生击杀 / 掉落 / 计数 / 经验 | 完整（与玩家击杀一致） | 完整（与玩家击杀一致） |
| 加成掉落 | **完整** | **可能缺失**：这一部分掉落是 `Monster.InitializeForLocation` 在怪物首次 `update` 时追加的（`sv-Monster.cs:476-520`），没被 `update` 过的怪物根本没有那几条掉落项 |

「加成掉落」具体指什么（源码 `sv-Monster.cs:482-518`）：

- **钻石 `72` / 五彩碎片 `74`**：条件是「矿井类怪物 + 玩家至少到过一次矿井底部」，概率 `Game1.random.NextDouble() < 0.001 + GetAdditionalDifficulty()*0.001`，命中后两者随机取一。
  （即**基础 0.1%**，危险矿井/骷髅洞穴每点额外难度再加 0.1%。任务书里写的「0.05%」低于源码值，这里以源码为准。）
- **齐豆 `890`**：仅在特殊订单规则 `DROP_QI_BEANS` 生效期间，概率 5%（尘灵 2%）。
- **彩蛋 `CalicoEgg`**：仅在沙漠节期间、骷髅洞穴且层数 > 120 时按公式计算（上限 50%），一次追加 1–3 个。

也就是说：**只有当你已经到过矿井底部**（以及在做齐豆订单、赶上沙漠节时）这一项才有意义 —— 但一旦有，`DelayOneFrame=true` 才是「一滴都不少」的那个模式。这也是当前默认值取 `true` 的原因（用户明确要求「我需要掉的东西」）。

### 3.2 游戏内改设置：F9 菜单与 GMCM（v1.2.0 新增）

从 1.2.0 起不必再手改 `config.json`，一共三条路，改完**立即生效**：

1. **F9 热键菜单（本模组自带，无任何依赖）**：按 `F9` 打开一个原生风格的设置面板，里面就是上面那三项。
   - **开在哪里**：游戏内（当前没有其它菜单时）与**标题界面**都能开；开着背包、箱子、对话、读档界面时按 `F9` 不会有反应（不抢焦点）。
   - **怎么点**：鼠标点任意一行即切换该开关，**同一次点击里就把新值写回 `config.json`**（`helper.WriteConfig`）。
   - **怎么关**：`Esc`、鼠标右键、右上角那个原生的 ✕，或者再按一次 `F9`。
   - **画的是什么**：面板框、勾选框、悬停高亮、字体**全部是游戏自带资源**（`Game1.menuTexture` 的标准菜单框与按钮底纹、`Game1.mouseCursors` 上原生 `OptionsCheckbox` 用的那对勾选精灵 `(227,425,9,9)`/`(236,425,9,9)`、`Game1.dialogueFont` / `Game1.smallFont`），**没有新增任何图片或字体文件**。
   - **中文/英文**：菜单文字是中文；如果玩家把游戏语言设成英文，按钮名仍能正常显示（本项目目前只写了中文文案，属于已知小瑕疵）。
2. **GMCM（Generic Mod Config Menu）**：装了 GMCM 的话，标题界面 `Mod Options` → `AutoKillBugs` 里会出现同样三项（含每一项的说明文字），GMCM 的 `Reset` 按钮会把三项恢复成默认值（全 `true`）。这是**可选**对接：没装 GMCM 时本模组静默跳过 —— 不报错、不记 Error、不影响加载，F9 菜单照常可用。
3. **手改 `config.json`**：与 1.1.0 完全一样，仍然有效。

菜单里的三项与 §3 表格一一对应：`Enabled`（总开关）、`OnlyInMines`（只在矿井生效）、`DelayOneFrame`（延迟一帧击杀）。**菜单只改这三个布尔值，不碰任何游戏状态**（不写存档、不加物品、不动怪物对象）；改完后下一帧的击杀判定立刻按新值走 —— `Enabled`/`OnlyInMines` 由 `GameLoop.UpdateTicked` 每次读、`DelayOneFrame` 由 `BugKiller` 每次用到时才读，而菜单/GMCM 改的就是 `ModEntry` 里那**同一个** `ModConfig` 实例，所以不需要重新读档，也不需要重启游戏。

## 4. 安装步骤

> ⚠️ 版本状态（2026-10-17 更新）：
> - **游戏里当前生效的是 1.2.0**（含 F9 设置菜单 + GMCM 对接）：2026-10-17 由 captain 用 `install.ps1` 部署完成，**退出码 0**，5 步全部 OK，部署前先确认过未检测到星露谷 / SMAPI 进程。源产物、`dist\AutoKillBugs\`、游戏 `Mods\AutoKillBugs\` **三处同哈希**：`AutoKillBugs.dll` **31232 字节** / SHA256 **`73089FC55A6CF8FD53EAAF64E8B343BD6258AAAAA502ED203ABF39F3A435EDC9`**（`FileVersion 1.2.0.0`）；`manifest.json` 684 字节 / `AA17DB5ACAC56548…`；`config.json` 70 字节 / `4D70BF5D25503430…`；`README.md`（本文件，只供阅读、不参与 SMAPI 加载，会随文档修订而变化，故不自列哈希）。1.1.0 的 `config.json` 已含 `DelayOneFrame` 且默认值与 1.2.0 相同，所以从 1.1.0 升到 1.2.0 不需要改 `config.json`。
> - 被替换掉的 **1.1.0 已完整备份**到 `_mods\autokill\_backup\installed-v1.1.0\`（`AutoKillBugs.dll` 20992 字节 / `CE3B6A6E6AC1ED0D16E031461299AD981848C9822203420DD3984062FE52C4E2`）；更早的 1.0.0 备份在 `_backup\installed-v1.0.0\`（dll 18944 字节 / `B016B90BB1326D7E0416A436378CE086DEE86D8A745C9199A96CA50E4760762E`）。**回滚** = 把对应备份目录整个复制回 `Mods\AutoKillBugs\` 覆盖即可。
> - 部署前、部署后各做一次存档 SHA256 比对，并另用 `_verify\Check-SavesIntegrity.ps1` 独立复核：**VERDICT: PASS、9/9 文件逐字节一致、0 新增 0 删除 0 改动**（两个脚本退出码均为 0）。本模组的开发与部署过程**从未**向存档目录写入任何文件。
> - 1.2.0 的独立验证判定在 `_verify\T2-VERIFY-REPORT.md`（21245 字节）：**VERDICT: pass** —— 沙箱独立重编译后 **IL 差异 0 行**（规范化 IL 同 SHA256、3297 行、88 个方法体 RVA 逐条相同）、反编译 C# **差异 0 行**；击杀逻辑零改动（`damageMonster` 全程序集唯一 1 处、11 个实参 IL 逐字一致）；`characters.Remove` / `IsInvisible` / `takeDamage` / `.Health=0` 全 0 命中；无任何存档或文件系统调用。唯一差异是 PE 布局 20 字节（`.text` 尾部与 `DataDir[15]` 的 RVA），源码与 IL 完全等价。
> - 本文件所在目录 `D:\deepseek\电脑\_mods\autokill\AutoKillBugs\` 与 `dist\AutoKillBugs\` 是同一份产物来源；下面第 4 步的复制步骤只在需要重新部署时使用。

1. 确认环境：星露谷物语 **1.6.15**、SMAPI **4.5.2**（本机已符合）。
2. 找到模组文件夹 `AutoKillBugs\`（构建产物目录：`D:\deepseek\电脑\_mods\autokill\AutoKillBugs\`）。
3. 该文件夹里部署需要的文件是这几个：`AutoKillBugs.dll`、`manifest.json`、`config.json`、`README.md`（构建时会自动把本文件放进去）；开发目录里还会同时存在 `.cs` 源码与 `bin/`、`obj/`，部署时不需要它们。
4. 把整个 `AutoKillBugs` 文件夹**复制**到游戏的 Mods 目录：`E:\SteamLibrary\steamapps\common\Stardew Valley\Mods\`。
   最终路径形如 `...\Stardew Valley\Mods\AutoKillBugs\AutoKillBugs.dll`。
5. 启动游戏。SMAPI 控制台应出现一行 INFO：
   `AutoKillBugs 已载入：蛆(Grub)/苍蝇(Fly)（含危险矿井与突变虫穴的强化变体）一出现就按游戏原生击杀流程死亡…`
6. **卸载**：删掉 `Mods\AutoKillBugs\` 整个文件夹即可，不需要动存档（本模组从不写存档）。

## 5. 日志与音效抑制

- **启动**：1 行 INFO，包含配置值、音效抑制是否安装成功，以及 F9 提示。如果玩家装了 GMCM，会在 `GameLaunched` 之后再多 1 行 INFO 确认「三项设置已注册到它的配置界面」；没装 GMCM 则完全静默（不报错、不记 Error、不记 WARN）。
- **每次击杀**：1 行 **DEBUG**（含怪物名、是否强化变体、地点、本次会话累计击杀数）。默认控制台看不到 DEBUG 级别，需要排查时再调 SMAPI 日志级别。
- **音效抑制**：蛆/苍蝇死亡时的音效是 `currentLocation.playSound(...)` 且不带位置参数 —— 游戏内部对「没有位置」的音效按满音量播放（不会因为怪在屏幕外就听不见），所以必须显式压掉，否则玩家会听到「看不到的东西在死」。做法是给 `GameLocation.playSound` 装一个 Harmony 前缀补丁，**只在自动击杀那一瞬间**跳过播放。补丁安装失败也不影响主功能，日志里会有 WARN。

## 6. 已知边界（如实说明）

- **只处理玩家当前所在地点**：别处（例如已经离开的矿层）的怪物不会被远程清空。
- **多人游戏只在主机端处理**：怪物由主机持有，客机端强改 `characters` 会造成不同步；客机端会记一条 WARN 并保持不动。
- **蛹化中的蛆**：蛆被打到半血会进入蛹化（此时对伤害完全免疫），然后变成苍蝇。本模组会把 `pupating` 标志解除后再击杀；万一是它先蛹化成功变成了苍蝇，那只新苍蝇同样会被立刻处理（类型判断覆盖 `Fly`），不会漏。
- **延迟模式的「闪一帧」**：`DelayOneFrame=true`（默认）时虫子会完整显示一帧（约 1/60 秒）才死亡；若它恰好出现在屏幕中央会有一瞬间的可见。想彻底看不到就把该项改成 `false`，代价是可能少拿 §3.1 里那部分加成掉落。另外延迟一帧让苍蝇有机会执行一次自己的 `updateAnimation`，因此它的 `flybuzzing` 嗡鸣**可能**会起一个头（音量为 0 起算），并在它死亡的那一刻被游戏自己停掉（`sv-Fly.cs:104`）。
- **加成掉落有前置条件**：§3.1 的钻石/五彩碎片只在「玩家至少到过矿井底部一次」之后才可能出现（`sv-Monster.cs:482` 的 `maxTimesReachedMineBottom() >= 1`），齐豆与彩蛋还分别要求特殊订单、沙漠节。没满足条件时两种模式的掉落完全一样。
- **音效抑制依赖 Harmony**：失败时功能不受影响，只是能听到音效。
- **没有在真实游戏里运行验证过**：本次制作全程禁止加载用户存档，验证阶段也没有启动过游戏，因此验证是**静态验证**（编译器 0 警告 0 错误、程序集元数据、反编译源码逐行对照、IL 调用点、产物哈希与完整性）。模组本身已在验证通过后由 captain 部署进 `Mods\`（见 §4 版本状态），但**部署不等于运行验证** —— 第一次真正跑起来是玩家启动游戏的时候。**F9 菜单与 GMCM 对接同样是静态验证**：菜单的每个游戏 API 调用点都对着本机反编译源码核过（`IClickableMenu` / `TitleMenu` / `OptionsCheckbox` / `Game1` 的行号写在 §8 与 `SettingsMenu.cs` 注释里），但**没有实际按过 F9、没有实际点过开关、也没有在装了 GMCM 的环境里打开过 Mod Options**。
- **设置菜单的边界**：① 只在「当前没有别的菜单」时才打开（游戏内要求 `Game1.activeClickableMenu == null`，标题界面要求 `TitleMenu.subMenu == null`），所以开着背包/箱子/对话/读档界面时按 F9 不会有反应；② 标题界面下菜单挂在 `TitleMenu.subMenu` 上，**不是**替换 `Game1.activeClickableMenu`（后者会销毁标题界面本身，原因见 §8）；③ 菜单只切换三个布尔值，不改任何游戏状态。
- **`Esc` 在标题界面的处理方式**：标题界面把按键转给子菜单时会**故意跳过**玩家的菜单键（默认 `Esc`，`TitleMenu.cs:740`），所以标题界面下的 `Esc` 关闭由本模组自己订阅的输入事件补上（`helper.Input.Suppress` 掉这次按键），而不是靠游戏的转发。
- **三个已知的低危瑕疵（独立静态审计发现，均保留未修，不影响核心功能）**：① 按 F9 时若因为「当前已开着别的菜单」而没打开设置菜单，这次 F9 按键仍会被 `Input.Suppress` 吞掉 —— 不会传给其它模组，也不会触发游戏功能（星露谷默认没给 F9 绑定任何功能）；② 菜单 `draw` 里没有同步 `Game1.options.mouseY`，鼠标「是否悬停在菜单上」的判定可能走默认分支（只影响视觉细节）；③ `CloseMenu()` 没有自校验 `TitleMenu.subMenu` 是否仍指向自己（静态分析判定该路径不可达）。
- **本模组不做**：不修改游戏存档、不修改刷怪表、不隐藏贴图、不直接删除怪物对象、不直接调用 `takeDamage`。

## 7. 技术要点速查（给维护者）

| 项目 | 值 |
| --- | --- |
| 程序集 | `AutoKillBugs.dll` v**1.2.0**（net6.0，与游戏自包含的 .NET 6.0.32 匹配）；31232 字节、SHA256 `73089FC5…35EDC9`（完整值见 §4） |
| UniqueID | `ModDev.AutoKillBugs` |
| 设置入口① | 热键 **F9**（`SButton.F9`，处理在 `ModEntry.OnButtonPressed`）→ `SettingsMenu : StardewValley.Menus.IClickableMenu`（新文件 `SettingsMenu.cs`）：游戏内挂 `Game1.activeClickableMenu`，标题界面挂 `TitleMenu.subMenu` |
| 设置入口② | GMCM（`spacechase0.GenericModConfigMenu`，**可选**）：`GameLaunched` 里 `helper.ModRegistry.GetApi<IGenericModConfigMenuApi>(…)`；拿到就 `Register` + `AddSectionTitle` + 3×`AddBoolOption`，拿不到（返回 `null`）静默跳过 |
| 配置落盘 | `IModHelper.WriteConfig`（F9 菜单点一下写一次；GMCM 的 Save 写一次）。**全源码没有其它任何写盘调用**（无 `System.IO` / `File.` / `Directory.`，已按关键字扫描全源码确认 0 命中） |
| 挂载点 | `IModHelper.Events.GameLoop.UpdateTicked`（`Game1.Update` 之后、本帧 Draw 之前） |
| 击杀时机 | 由 `DelayOneFrame` 决定：`false` = 当帧扫描并击杀（一帧都不画）；`true` = 当帧只把候选登记进 `PendingTargets`，下一 tick 校验（仍在 `characters`、`Health > 0`、`currentLocation` 未变）后才击杀，从而保证 `Monster.update` → `InitializeForLocation` 已跑过 |
| 击杀调用 | `GameLocation.damageMonster(hitbox, 999999, 999999, isBomb: false, knockBackModifier: 0f, addedPrecision: 10, critChance: 0f, critMultiplier: 1f, triggerMonsterInvincibleTimer: false, who: Game1.player, isProjectile: true)` |
| 目标判定 | `monster is Grub \|\| monster is Fly`（与游戏自身 `BugLand.DayUpdate` 的写法一致） |

## 8. v1.2.0 相对 v1.1.0 的差异

**只增不改**：击杀逻辑（`BugKiller.cs`、`SoundSuppressor.cs`、`ModConfig.cs`）**一个字节都没动** —— 这三个文件的最后修改时间仍停在 1.1.0 制作时段（本次修改开始于 03:09），本次只新增「设置入口」这一件事，外加 `ModEntry.cs` 里的注册代码与一个新文件 `SettingsMenu.cs`。

| | v1.1.0 | v1.2.0 |
| --- | --- | --- |
| 改设置的方式 | 只能手改 `config.json` | ① **F9 菜单**（游戏内 / 标题界面都能开，点一下立即生效并落盘）② **GMCM**（装了就在标题界面 `Mod Options` 里调）③ 手改 `config.json`（仍然有效） |
| 新增文件 | — | `SettingsMenu.cs`（唯一的新文件：原生风格设置菜单，无新增贴图/字体/资源） |
| 改动文件 | — | `ModEntry.cs`（加两个事件订阅 + GMCM 注册 + 输入处理）、`AutoKillBugs.csproj`（版本号 1.2.0）、`manifest.json`（`Version` 1.2.0）、`README.md`（本文件） |
| 程序集 | 20992 字节 / `1.1.0.0` | **31232 字节 / `1.2.0.0`** |
| 运行时依赖 | 无 | 无（GMCM **可选**：不装照常工作，不装不会报错也不会记 Error） |

两个关键技术决定（都有本机反编译源码依据）：

1. **标题界面不直接替换 `Game1.activeClickableMenu`**：标题界面本身就是 `Game1.activeClickableMenu`（`Game1.cs:2598` `activeClickableMenu = new TitleMenu()`），而该属性的 setter 会把被替换掉的旧菜单 `Dispose()` 掉（`Game1.cs:1687`）—— 直接换成我们的菜单 = 把标题界面本身销毁，关掉后再赋回去就是画一个已释放的对象（黑屏/崩溃）。所以标题界面走游戏自己的 `TitleMenu.subMenu`（`TitleMenu.cs:194-224`）：此时 `Game1.activeClickableMenu` 全程不变，而关闭时由 setter 事先挂到我们菜单 `exitFunction` 上的 `TitleMenu.CloseSubMenu`（`TitleMenu.cs:216`）完成原生收尾（`TitleMenu.cs:867-873`）。反过来说：**绝不能**在关闭时自己去把 `TitleMenu.subMenu` 置 `null` —— 那会先把 `exitFunction` 清掉（`TitleMenu.cs:204`），标题按钮就再也滑不回来了。
2. **标题界面的 `Esc` 需要自己兜底**：`TitleMenu.receiveKeyPress` 把按键转给子菜单前会排除玩家的菜单键（`TitleMenu.cs:740`），所以标题界面下 `Esc` 走不到菜单里，由 `ModEntry.OnButtonPressed` 补上。游戏内不需要这一步（那时菜单就是 `Game1.activeClickableMenu`，`Esc` 由游戏自己转发进来，最终命中 `IClickableMenu.receiveKeyPress`）。

**没有改动的部分（逐项核对过）**：`damageMonster` 的 11 个实参逐字不变、pupating 解除与失败回滚不变、`SoundSuppressor.Begin/End` 的 try-finally 位置不变、`SuppressDeathEffects` 清理不变、待杀集合的四问（`IsStillKillableIn` 三条件 + `DiscardPendingTargets` 时机）不变、`DelayOneFrame` 两分支语义不变。这些代码所在的三个文件在本次改动中**未被打开写入**。

细节与源码证据（含反编译行号）见同目录的 `RESEARCH.md` 与 `BUILD.md`。
